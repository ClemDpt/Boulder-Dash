const divMap = document.querySelector("#bricks");
const time = document.querySelector("#timer");
const scoreEl = document.querySelector("#scoreEl");
const lifeEl= document.querySelector("#lifeEl");
const endSreen = document.querySelector("#endScreen");


let Pos_x = 0;
let Pos_y = 0;
let x = 0;
let y = 0;
let score = 0;
let life = 3;
let tableau = [//INITIALISATION DU PREMIER NIVEAU
    ["M", "M", "M", "M", "M", "M", "M", "M", "M", "M", "M", "M", "M", "M", "M", "M", "M", "M", "M", "M", "M", "M", "M", "M", "M", "M", "M", "M", "M", "M", "M", "M"],
    ["M", "T", "T", "T", "T", "T", "T", "V", "T", "T", "T", "T", "R", "V", "T", "T", "T", "T", "T", "R", "T", "R", "T", "T", "T", "T", "T", "T", "T", "V", "T", "M"],
    ["M", "T", "R", "P", "R", "T", "T", "T", "T", "T", "T", "V", "T", "T", "T", "T", "T", "T", "T", "T", "T", "R", "D", "T", "T", "R", "T", "T", "T", "T", "D", "M"],
    ["M", "T", "T", "T", "T", "T", "T", "T", "T", "T", "T", "V", "T", "T", "R", "T", "T", "T", "T", "T", "R", "T", "R", "T", "T", "R", "T", "T", "T", "T", "T", "M"],
    ["M", "R", "T", "R", "R", "T", "T", "T", "T", "T", "T", "T", "T", "T", "R", "T", "T", "T", "T", "T", "T", "R", "T", "T", "R", "T", "T", "T", "T", "R", "T", "M"],
    ["M", "R", "T", "V", "R", "T", "T", "T", "T", "T", "T", "T", "T", "T", "V", "R", "T", "T", "R", "T", "T", "T", "T", "T", "T", "T", "T", "R", "T", "T", "T", "M"],
    ["M", "T", "T", "T", "V", "T", "T", "R", "T", "T", "T", "T", "T", "T", "T", "T", "R", "T", "T", "T", "T", "T", "R", "T", "V", "R", "T", "T", "T", "T", "T", "M"],
    ["M", "C", "C", "C", "C", "C", "C", "C", "C", "C", "C", "C", "C", "C", "C", "C", "C", "C", "C", "C", "C", "C", "T", "T", "T", "T", "T", "R", "R", "R", "T", "M"],
    ["M", "T", "V", "T", "T", "T", "R", "T", "T", "D", "T", "V", "T", "T", "R", "T", "R", "T", "T", "T", "T", "T", "T", "T", "T", "T", "T", "D", "T", "R", "D", "M"],
    ["M", "T", "T", "T", "D", "T", "T", "T", "T", "R", "T", "T", "T", "T", "T", "V", "T", "T", "T", "T", "T", "T", "T", "T", "R", "R", "V", "R", "T", "T", "R", "M"],
    ["M", "T", "T", "T", "R", "T", "T", "T", "T", "R", "T", "T", "T", "T", "T", "T", "T", "T", "T", "T", "T", "T", "T", "T", "R", "V", "T", "R", "T", "T", "R", "M"],
    ["M", "T", "R", "T", "T", "T", "T", "T", "R", "T", "T", "T", "T", "T", "T", "T", "T", "R", "R", "R", "T", "T", "T", "T", "T", "T", "T", "R", "T", "T", "V", "M"],
    ["M", "T", "D", "T", "T", "V", "T", "T", "R", "T", "V", "V", "T", "T", "T", "T", "T", "R", "T", "R", "D", "T", "T", "D", "T", "T", "T", "T", "R", "T", "T", "M"],
    ["M", "T", "V", "R", "T", "T", "T", "T", "T", "T", "T", "T", "T", "T", "T", "T", "T", "T", "T", "V", "R", "T", "T", "R", "T", "T", "T", "T", "T", "T", "T", "M"],
    ["M", "T", "T", "T", "T", "T", "T", "T", "T", "C", "C", "C", "C", "C", "C", "C", "C", "C", "C", "C", "T", "T", "T", "T", "T", "T", "T", "T", "T", "T", "T", "M"],
    ["M", "M", "M", "M", "M", "M", "M", "M", "M", "M", "M", "M", "M", "M", "M", "M", "M", "M", "M", "M", "M", "M", "M", "M", "M", "M", "M", "M", "M", "M", "M", "M"]
]

//AFFICHAGE DU NIVEAU
function afficherMap() {
    let txt = "";

    for (let i=0; i<tableau.length; i++){
        txt += "<div>";
        
        for (let j=0; j<tableau[i].length; j++){
            if (tableau[i][j] == 'M') {
                txt += "<img src='./../textures/obsidian.png'>";
            } else if (tableau[i][j] == 'T') {
                txt += "<img src='./../textures/dirt.png'>";
            } else if (tableau[i][j] == 'D') {
                txt += "<img src='./../textures/coin.gif'>";
            } else if (tableau[i][j] == 'R') {
                txt += "<img src='./../textures/stone.png'>";
            } else if (tableau[i][j] == 'C') {
                txt += "<img style='width:14px;' src='./../textures/ground.png'> ";
            } else if (tableau[i][j] == 'V') {
                txt += "<img src='./../textures/teleport.png'>";
            } else if (tableau[i][j] == 'P') {
                txt += "<img src='./../textures/player_stay.gif'>";
            }
        }

        txt += "</div>";
    }

    divMap.innerHTML = txt;
    setInterval(gravity, 100);
    //gravity();
}

//DECOMPTE DIAMANTS DE LA CARTE

//DECOMPTE DIAMANTS + DEPLACEMENTS DU JOUEUR

let coinScore = 0;
function refreshSB() {
    const coinScoreElement = document.getElementById("coin_score");
    coinScoreElement.textContent = coinScore;
}

//DEPLACEMENTS DU JOUEUR
function move(e) {

    tableau.forEach((row, i) => {
        row.forEach((symbol, j) => {
            if (symbol == 'P') {
                Pos_x = i;
                Pos_y = j;
            }
        })
    })
    //S'IL ENTRE LA TOUCHE Z
    if (e.keyCode == 90) {
        if (tableau[Pos_x - 1][Pos_y] == 'T' || tableau[Pos_x - 1][Pos_y] == 'V') {
            tableau[Pos_x - 1][Pos_y] = 'P';
            tableau[Pos_x][Pos_y] = 'V';
        } else if (tableau[Pos_x - 1][Pos_y] == 'M' || tableau[Pos_x - 1][Pos_y] == 'C' || tableau[Pos_x - 1][Pos_y] == 'R') {
            tableau[Pos_x][Pos_y] = 'P';
        } else if (tableau[Pos_x - 1][Pos_y] == 'D') {
            tableau[Pos_x - 1][Pos_y] = 'P';
            tableau[Pos_x][Pos_y] = 'V';
            ++coinScore;
            score += 10
            scoreEl.innerHTML = score;
        }
        afficherMap();
    }//S'IL ENTRE LA TOUCHE S
    else if (e.keyCode == 83) {
        if (tableau[Pos_x + 1][Pos_y] == 'T' || tableau[Pos_x + 1][Pos_y] == 'V') {
            tableau[Pos_x + 1][Pos_y] = 'P';
            tableau[Pos_x][Pos_y] = 'V';
        } else if (tableau[Pos_x + 1][Pos_y] == 'M' || tableau[Pos_x + 1][Pos_y] == 'C' || tableau[Pos_x - 1][Pos_y] == 'R') {
            tableau[Pos_x][Pos_y] = 'P';
        } else if (tableau[Pos_x + 1][Pos_y] == 'D') {
            tableau[Pos_x + 1][Pos_y] = 'P';
            tableau[Pos_x][Pos_y] = 'V';
            ++coinScore;
            score += 10
            scoreEl.innerHTML = score;
        }
        afficherMap();
    }//S'IL ENTRE LA TOUCHE D
    else if (e.keyCode == 68) {
        if (tableau[Pos_x][Pos_y + 1] == 'T' || tableau[Pos_x][Pos_y + 1] == 'V') {
            tableau[Pos_x][Pos_y + 1] = 'P';
            tableau[Pos_x][Pos_y] = 'V';
        } else if (tableau[Pos_x][Pos_y + 1] == 'M' || tableau[Pos_x][Pos_y + 1] == 'C') {
            tableau[Pos_x][Pos_y] = 'P';
        } else if (tableau[Pos_x][Pos_y + 1] == 'D') {
            tableau[Pos_x][Pos_y + 1] = 'P';
            tableau[Pos_x][Pos_y] = 'V';
            ++coinScore;
            score += 10
            scoreEl.innerHTML = score;
        } else if (tableau[Pos_x][Pos_y + 1] == 'R' && tableau[Pos_x][Pos_y + 2] == 'V') {
            tableau[Pos_x][Pos_y + 1] = 'P';
            tableau[Pos_x][Pos_y + 2] = 'R';
            tableau[Pos_x][Pos_y] = 'V';
        } else if (tableau[Pos_x][Pos_y + 1] == 'R' && (tableau[Pos_x][Pos_y + 2] == 'M' || tableau[Pos_x][Pos_y + 2] == 'C' || tableau[Pos_x][Pos_y + 2] == 'T' || tableau[Pos_x][Pos_y + 2] == 'D')) {
            tableau[Pos_x][Pos_y] = 'P';
        }

        afficherMap();
    }//S'IL ENTRE LA TOUCHE Q
    else if (e.keyCode == 81) {
        if (tableau[Pos_x][Pos_y - 1] == 'T' || tableau[Pos_x][Pos_y - 1] == 'V') {
            tableau[Pos_x][Pos_y - 1] = 'P';
            tableau[Pos_x][Pos_y] = 'V';
        } else if (tableau[Pos_x][Pos_y - 1] == 'M' || tableau[Pos_x][Pos_y - 1] == 'C') {
            tableau[Pos_x][Pos_y] = 'P';
        } else if (tableau[Pos_x][Pos_y - 1] == 'D') {
            tableau[Pos_x][Pos_y - 1] = 'P';
            tableau[Pos_x][Pos_y] = 'V';
            ++coinScore;
            score += 10
            scoreEl.innerHTML = score;
        } else if (tableau[Pos_x][Pos_y - 1] == 'R' && tableau[Pos_x][Pos_y - 2] == 'V') {
            tableau[Pos_x][Pos_y - 1] = 'P';
            tableau[Pos_x][Pos_y - 2] = 'R'
            tableau[Pos_x][Pos_y] = 'V';
        } else if (tableau[Pos_x][Pos_y - 1] == 'R' && (tableau[Pos_x][Pos_y - 2] == 'M' || tableau[Pos_x][Pos_y - 2] == 'C' || tableau[Pos_x][Pos_y - 2] == 'T' || tableau[Pos_x][Pos_y - 2] == 'D')) {
            tableau[Pos_x][Pos_y] = 'P';
        }
        afficherMap(); 
    }
    refreshSB();
    
}

//GRAVITE
function gravity() {

    tableau.forEach((row, i) => {
        row.forEach((symbol, j) => {
            if (symbol == 'R') {
                x = i;
                y = j;
                if (tableau[x + 1][y] == 'V') {
                    tableau[x + 1][y] = 'R';
                    tableau[x][y] = 'V';
                    afficherMap();
                    if (tableau[x + 1][y] == 'P') {
                    life -= life;
                        if (life > 0) {
                            reset();
                        } else if (life == 0) {
                            gameOver();
                        }

                    }
                }
            }
        })
    })

}



//TIMER 
function timer() {
    let tempsmax=200; 
    const timerElement = document.getElementById("timer")
    setInterval(() => {
        timerElement.textContent = `Timer : ${tempsmax}`
        tempsmax = tempsmax <= 0 ? 0 : tempsmax-1
    }, 1000)
}

//RESET
function reset() {
    coinScore = 0;
    score = 0;
    life -= life;
    scoreEl.innerHTML = score;
    lifeEl.innerHTML = life;
    afficherMap();
}

//GAME OVER
function gameOver() {
    endSreen.innerHTML = `<div class="gameOver">Game over <br/>score : ${score} </div>`;
    endSreen.style.visibility = 'visible';
    endSreen.style.opacity = '1';
};


//APPEL DES FONCTIONS
    
afficherMap();
timer();
document.body.addEventListener('keydown', move);
