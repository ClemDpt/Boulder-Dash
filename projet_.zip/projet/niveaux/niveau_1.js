

let map = [
    ["M", "M", "M", "M", "M", "M", "M", "M", "M", "M", "M", "M", "M", "M", "M", "M", "M", "M", "M", "M", "M", "M", "M", "M", "M", "M", "M", "M", "M", "M", "M", "M"],
    ["M", "T", "T", "T", "T", "T", "T", "V", "T", "T", "T", "T", "R", "V", "T", "T", "T", "T", "T", "R", "T", "R", "T", "T", "T", "T", "T", "T", "T", "V", "T", "M"],
    ["M", "T", "R", "P", "R", "T", "T", "T", "T", "T", "T", "V", "T", "T", "T", "T", "T", "T", "T", "T", "T", "R", "D", "T", "T", "R", "T", "T", "T", "T", "D", "M"],
    ["M", "T", "T", "T", "T", "T", "T", "T", "T", "T", "T", "V", "T", "T", "R", "T", "T", "T", "T", "T", "R", "T", "R", "T", "T", "R", "T", "T", "T", "T", "T", "M"],
    ["M", "R", "T", "R", "R", "T", "T", "T", "T", "T", "T", "T", "T", "T", "R", "T", "T", "T", "T", "T", "T", "R", "T", "T", "R", "T", "T", "T", "T", "R", "T", "M"],
    ["M", "R", "T", "V", "R", "T", "T", "T", "T", "T", "T", "T", "T", "T", "V", "R", "T", "T", "R", "T", "T", "T", "T", "T", "T", "T", "T", "R", "T", "T", "T", "M"],
    ["M", "T", "T", "T", "V", "T", "T", "R", "T", "T", "T", "T", "T", "T", "T", "T", "R", "T", "T", "T", "T", "T", "R", "T", "V", "R", "T", "T", "T", "T", "T", "M"],
    ["M", "cobble", "cobble", "cobble", "cobble", "cobble", "cobble", "cobble", "cobble", "cobble", "cobble", "cobble", "cobble", "cobble", "cobble", "cobble", "cobble", "cobble", "cobble", "cobble", "cobble", "cobble", "T", "T", "T", "T", "T", "R", "R", "R", "T", "T", "M"],
    ["M", "T", "V", "T", "T", "T", "R", "T", "T", "D", "T", "V", "T", "T", "R", "T", "R", "T", "T", "T", "T", "T", "T", "T", "T", "T", "T", "D", "T", "R", "D", "M"],
    ["M", "T", "T", "T", "D", "T", "T", "T", "T", "R", "T", "T", "T", "T", "T", "V", "T", "T", "T", "T", "T", "T", "T", "T", "R", "R", "V", "R", "T", "T", "R", "M"],
    ["M", "T", "T", "T", "R", "T", "T", "T", "T", "R", "T", "T", "T", "T", "T", "T", "T", "T", "T", "T", "T", "T", "T", "T", "R", "V", "T", "R", "T", "T", "R", "M"],
    ["M", "T", "R", "T", "T", "T", "T", "T", "R", "T", "T", "T", "T", "T", "T", "T", "T", "R", "R", "R", "T", "T", "T", "T", "T", "T", "T", "R", "T", "T", "V", "M"],
    ["M", "T", "D", "T", "T", "V", "T", "T", "R", "T", "V", "V", "T", "T", "T", "T", "T", "R", "T", "R", "D", "T", "T", "D", "T", "T", "T", "T", "R", "T", "T", "M"],
    ["M", "T", "V", "R", "T", "T", "T", "T", "T", "T", "T", "T", "T", "T", "T", "T", "T", "T", "T", "V", "R", "T", "T", "R", "T", "T", "T", "T", "T", "T", "T", "M"],
    ["M", "T", "T", "T", "T", "T", "T", "T", "T", "cobble", "cobble", "cobble", "cobble", "cobble", "cobble", "cobble", "cobble", "cobble", "cobble", "cobble", "T", "T", "T", "T", "T", "T", "T", "T", "T", "T", "T", "M"],
    ["M", "M", "M", "M", "M", "M", "M", "M", "M", "M", "M", "M", "M", "M", "M", "M", "M", "M", "M", "M", "M", "M", "M", "M", "M", "M", "M", "M", "M", "M", "M", "M"]
]


divMap.innerHTML = txt;
afficherMap(map);
