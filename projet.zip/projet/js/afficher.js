const divMap = document.querySelector("#bricks");

let Pos_x = 0;
let Pos_y = 0;
let x = 0;
let y = 0;
let tableau = [//INITIALISATION DU PREMIER NIVEAU
    ["M", "M", "M", "M", "M", "M", "M", "M", "M", "M", "M", "M", "M", "M", "M", "M", "M", "M", "M", "M", "M", "M", "M", "M", "M", "M", "M", "M", "M", "M", "M", "M"],
    ["M", "T", "T", "T", "T", "T", "T", "V", "T", "T", "T", "T", "R", "V", "T", "T", "T", "T", "T", "R", "T", "R", "T", "T", "T", "T", "T", "T", "T", "V", "T", "M"],
    ["M", "T", "R", "P", "R", "T", "T", "T", "T", "T", "T", "V", "T", "T", "T", "T", "T", "T", "T", "T", "T", "R", "D", "T", "T", "R", "T", "T", "T", "T", "D", "M"],
    ["M", "T", "T", "T", "T", "T", "T", "T", "T", "T", "T", "V", "T", "T", "R", "T", "T", "T", "T", "T", "R", "T", "R", "T", "T", "R", "T", "T", "T", "T", "T", "M"],
    ["M", "R", "T", "R", "R", "T", "T", "T", "T", "T", "T", "T", "T", "T", "R", "T", "T", "T", "T", "T", "T", "R", "T", "T", "R", "T", "T", "T", "T", "R", "T", "M"],
    ["M", "R", "T", "V", "R", "T", "T", "T", "T", "T", "T", "T", "T", "T", "V", "R", "T", "T", "R", "T", "T", "T", "T", "T", "T", "T", "T", "R", "T", "T", "T", "M"],
    ["M", "T", "T", "T", "V", "T", "T", "R", "T", "T", "T", "T", "T", "T", "T", "T", "R", "T", "T", "T", "T", "T", "R", "T", "V", "R", "T", "T", "T", "T", "T", "M"],
    ["M", "C", "C", "C", "C", "C", "C", "C", "C", "C", "C", "C", "C", "C", "C", "C", "C", "C", "C", "C", "C", "C", "T", "T", "T", "T", "T", "R", "R", "R", "T", "M"],
    ["M", "T", "V", "T", "T", "T", "R", "T", "T", "D", "T", "V", "T", "T", "R", "T", "R", "T", "T", "T", "T", "T", "T", "T", "T", "T", "T", "D", "T", "R", "D", "M"],
    ["M", "T", "T", "T", "D", "T", "T", "T", "T", "R", "T", "T", "T", "T", "T", "V", "T", "T", "T", "T", "T", "T", "T", "T", "R", "R", "V", "R", "T", "T", "R", "M"],
    ["M", "T", "T", "T", "R", "T", "T", "T", "T", "R", "T", "T", "T", "T", "T", "T", "T", "T", "T", "T", "T", "T", "T", "T", "R", "V", "T", "R", "T", "T", "R", "M"],
    ["M", "T", "R", "T", "T", "T", "T", "T", "R", "T", "T", "T", "T", "T", "T", "T", "T", "R", "R", "R", "T", "T", "T", "T", "T", "T", "T", "R", "T", "T", "V", "M"],
    ["M", "T", "D", "T", "T", "V", "T", "T", "R", "T", "V", "V", "T", "T", "T", "T", "T", "R", "T", "R", "D", "T", "T", "D", "T", "T", "T", "T", "R", "T", "T", "M"],
    ["M", "T", "V", "R", "T", "T", "T", "T", "T", "T", "T", "T", "T", "T", "T", "T", "T", "T", "T", "V", "R", "T", "T", "R", "T", "T", "T", "T", "T", "T", "T", "M"],
    ["M", "T", "T", "T", "T", "T", "T", "T", "T", "C", "C", "C", "C", "C", "C", "C", "C", "C", "C", "C", "T", "T", "T", "T", "T", "T", "T", "T", "T", "T", "T", "M"],
    ["M", "M", "M", "M", "M", "M", "M", "M", "M", "M", "M", "M", "M", "M", "M", "M", "M", "M", "M", "M", "M", "M", "M", "M", "M", "M", "M", "M", "M", "M", "M", "M"]
]

//AFFICHAGE DU NIVEAU
function afficherMap() {
    let txt = "";

    for (let i=0; i<tableau.length; i++){
        txt += "<div>";
        
        for (let j=0; j<tableau[i].length; j++){
            if (tableau[i][j] == 'M') {
                txt += "<img src='./../textures/obsidian.png'>";
            } else if (tableau[i][j] == 'T') {
                txt += "<img src='./../textures/dirt.png'>";
            } else if (tableau[i][j] == 'D') {
                txt += "<img src='./../textures/coin.gif'>";
            } else if (tableau[i][j] == 'R') {
                txt += "<img src='./../textures/stone.png'>";
            } else if (tableau[i][j] == 'C') {
                txt += "<img style='width:14px;' src='./../textures/ground.png'> ";
            } else if (tableau[i][j] == 'V') {
                txt += "<img src='./../textures/teleport.png'>";
            } else if (tableau[i][j] == 'P') {
                txt += "<img src='./../textures/player_stay.gif'>";
            }
        }

        txt += "</div>";
    }

    divMap.innerHTML = txt;
    //gravity();
}

//MOUVEMENT DU JOUEUR
function move(e) {

    tableau.forEach((row, i) => {
        row.forEach((symbol, j) => {
            if (symbol == 'P') {
                Pos_x = i;
                Pos_y = j;
            }
        })
    })
    //S'IL ENTRE LA TOUCHE Z
    if (e.keyCode == 90) {
        if (tableau[Pos_x - 1][Pos_y] == 'T' || tableau[Pos_x - 1][Pos_y] == 'V') {
            tableau[Pos_x - 1][Pos_y] = 'P';
            tableau[Pos_x][Pos_y] = 'V';
        } else if (tableau[Pos_x - 1][Pos_y] == 'M' || tableau[Pos_x - 1][Pos_y] == 'C' || tableau[Pos_x - 1][Pos_y] == 'R') {
            tableau[Pos_x][Pos_y] = 'P';
        } else if (tableau[Pos_x - 1][Pos_y] == 'D') {
            tableau[Pos_x - 1][Pos_y] = 'P';
            tableau[Pos_x][Pos_y] = 'V';
        }
        afficherMap();
    }//S'IL ENTRE LA TOUCHE S
    else if (e.keyCode == 83) {
        if (tableau[Pos_x + 1][Pos_y] == 'T' || tableau[Pos_x + 1][Pos_y] == 'V') {
            tableau[Pos_x + 1][Pos_y] = 'P';
            tableau[Pos_x][Pos_y] = 'V';
        } else if (tableau[Pos_x + 1][Pos_y] == 'M' || tableau[Pos_x + 1][Pos_y] == 'C' || tableau[Pos_x - 1][Pos_y] == 'R') {
            tableau[Pos_x][Pos_y] = 'P';
        } else if (tableau[Pos_x + 1][Pos_y] == 'D') {
            tableau[Pos_x + 1][Pos_y] = 'P';
            tableau[Pos_x][Pos_y] = 'V';
        }
        afficherMap();
    }//S'IL ENTRE LA TOUCHE D
    else if (e.keyCode == 68) {
        if (tableau[Pos_x][Pos_y + 1] == 'T' || tableau[Pos_x][Pos_y + 1] == 'V') {
            tableau[Pos_x][Pos_y + 1] = 'P';
            tableau[Pos_x][Pos_y] = 'V';
        } else if (tableau[Pos_x][Pos_y + 1] == 'M' || tableau[Pos_x][Pos_y + 1] == 'C') {
            tableau[Pos_x][Pos_y] = 'P';
        } else if (tableau[Pos_x][Pos_y + 1] == 'D') {
            tableau[Pos_x][Pos_y + 1] = 'P';
            tableau[Pos_x][Pos_y] = 'V';
        } else if (tableau[Pos_x][Pos_y + 1] == 'R' & tableau[Pos_x][Pos_y + 2] == 'V') {
            tableau[Pos_x][Pos_y + 1] = 'P';
            tableau[Pos_x][Pos_y + 2] = 'R';
            tableau[Pos_x][Pos_y] = 'V';
        } else if (tableau[Pos_x][Pos_y + 1] == 'R' & (tableau[Pos_x][Pos_y + 2] == 'M' || tableau[Pos_x][Pos_y + 2] == 'C' || tableau[Pos_x][Pos_y + 2] == 'T' || tableau[Pos_x][Pos_y + 2] == 'D')) {
            tableau[Pos_x][Pos_y] = 'P';
        }

        afficherMap();
    }//S'IL ENTRE LA TOUCHE Q
    else if (e.keyCode == 81) {
        if (tableau[Pos_x][Pos_y - 1] == 'T' || tableau[Pos_x][Pos_y - 1] == 'V') {
            tableau[Pos_x][Pos_y - 1] = 'P';
            tableau[Pos_x][Pos_y] = 'V';
        } else if (tableau[Pos_x][Pos_y - 1] == 'M' || tableau[Pos_x][Pos_y - 1] == 'C') {
            tableau[Pos_x][Pos_y] = 'P';
        } else if (tableau[Pos_x][Pos_y - 1] == 'D') {
            tableau[Pos_x][Pos_y - 1] = 'P';
            tableau[Pos_x][Pos_y] = 'V';
        } else if (tableau[Pos_x][Pos_y - 1] == 'R' & tableau[Pos_x][Pos_y - 2] == 'V') {
            tableau[Pos_x][Pos_y - 1] = 'P';
            tableau[Pos_x][Pos_y - 2] = 'R'
            tableau[Pos_x][Pos_y] = 'V';
        } else if (tableau[Pos_x][Pos_y - 1] == 'R' & (tableau[Pos_x][Pos_y - 2] == 'M' || tableau[Pos_x][Pos_y - 2] == 'C' || tableau[Pos_x][Pos_y - 2] == 'T' || tableau[Pos_x][Pos_y - 2] == 'D')) {
            tableau[Pos_x][Pos_y] = 'P';
        }
        afficherMap(); 
    }
    
}

//GRAVITE
function gravity() {

    tableau.forEach((row, i) => {
        row.forEach((symbol, j) => {
            if (symbol == 'R') {
                x = i;
                y = j;
                let a = "";
                if (tableau[x + 1][y] == 'V') {
                    tableau[x + 1][y] = 'R';
                    tableau[x][y] = 'V';
                    afficherMap();
                } else if (tableau[x + 1][y] == 'P') {
                    a += "<img src='./../textures/explosion.gif'>";
                    tableau[Pos_x + 1][Pos_y] = 'a';
                    tableau[x][y] = 'V';
                    afficherMap();
                }

            }
        })
    })

}


//APPEL DES FONCTIONS
    
afficherMap();
document.body.addEventListener('keydown', move);







