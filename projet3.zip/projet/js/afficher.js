const divMap = document.querySelector("#bricks");
const scoreEl = document.querySelector("#scoreEl");
const lifeEl= document.querySelector("#lifeEl");
const endSreen = document.querySelector("#endScreen");


let Pos_x = 0;
let Pos_y = 0;
let x = 0;
let y = 0;
let life = 3;




//DECOMPTE DIAMANTS DE LA CARTE
let coinMap = 0;

//AFFICHAGE DU NIVEAU
function afficherMap() {
    var fichier = new File("niveau1.txt")
    
    let tableau = reader.readAsText(fichier);

    let txt = "";
    txt += "<div id='row'>";

    for (let i=0; i<34; i++){
        txt += "<img src='./../textures/obsidian.png'>";
    }
    
    txt += "</div>";
    for (let i=0; i<tableau.length; i++){
        txt += "<div id='row'>";
        txt += "<img src='./../textures/obsidian.png'>";
        for (let j=0; j<tableau[i].length; j++){
            
            if (tableau[i][j] == 'O') {
                txt += "<img src='./../textures/obsidian.png'>";
            } else if (tableau[i][j] == 'T') {
                txt += "<img src='./../textures/dirt.png'>";
            } else if (tableau[i][j] == 'D') {
                ++coinMap;
                txt += "<img src='./../textures/diamond_ore.png'>";
            } else if (tableau[i][j] == 'R') {
                txt += "<img src='./../textures/stone.png'>";
            } else if (tableau[i][j] == 'M') {
                txt += "<img src='./../textures/ground.png'>";
            } else if (tableau[i][j] == 'V') {
                txt += "<img src='./../textures/void.png'>";
            } else if (tableau[i][j] == 'P') {
                txt += "<img src='./../textures/player_stay.gif'>";
            }
        }
        txt += "<img src='./../textures/obsidian.png'>";
        txt += "</div>";
    }

    txt += "<div id='row'>";
    for (let i=0; i<34; i++){
        txt += "<img src='./../textures/obsidian.png'>";
    }
    txt += "</div>";

    divMap.innerHTML = txt;
    setInterval(gravity, 100);
    //gravity();
}

//DECOMPTE DIAMANTS + DEPLACEMENTS DU JOUEUR

let coinScore = 0;
let moveCount = 0;
let globalScore = 0;

function refreshSB() {
    const coinScoreElement = document.getElementById("coin_score");
    //const moveCountElement = document.getElementById("moveCount_score");
    const globalScoreElement = document.getElementById("globalScore");
    coinScoreElement.textContent = coinScore;
    //moveCountElement.textContent = moveCount;
    globalScoreElement.textContent = `Score : ${globalScore}`;
}

function compteCoinMap(){
    const coinMapElement = document.getElementById("coinMap");
    coinMapElement.textContent = coinMap;
}

//DEPLACEMENTS DU JOUEUR
function move(e) {

    tableau.forEach((row, i) => {
        row.forEach((symbol, j) => {
            if (symbol == 'P') {
                Pos_x = i;
                Pos_y = j;
            }
        })
    })
    //S'IL ENTRE LA TOUCHE Z
    if (e.keyCode == 90) {
        if (tableau[Pos_x - 1][Pos_y] == 'T' || tableau[Pos_x - 1][Pos_y] == 'V') {
            tableau[Pos_x - 1][Pos_y] = 'P';
            tableau[Pos_x][Pos_y] = 'V';
        } else if (tableau[Pos_x - 1][Pos_y] == 'M' || tableau[Pos_x - 1][Pos_y] == 'C' || tableau[Pos_x - 1][Pos_y] == 'R') {
            tableau[Pos_x][Pos_y] = 'P';
        } else if (tableau[Pos_x - 1][Pos_y] == 'D') {
            tableau[Pos_x - 1][Pos_y] = 'P';
            tableau[Pos_x][Pos_y] = 'V';
            ++coinScore;
            globalScore += 250;
        }
        afficherMap();
    }//S'IL ENTRE LA TOUCHE S
    else if (e.keyCode == 83) {
        if (tableau[Pos_x + 1][Pos_y] == 'T' || tableau[Pos_x + 1][Pos_y] == 'V') {
            tableau[Pos_x + 1][Pos_y] = 'P';
            tableau[Pos_x][Pos_y] = 'V';
        } else if (tableau[Pos_x + 1][Pos_y] == 'M' || tableau[Pos_x + 1][Pos_y] == 'C' || tableau[Pos_x - 1][Pos_y] == 'R') {
            tableau[Pos_x][Pos_y] = 'P';
        } else if (tableau[Pos_x + 1][Pos_y] == 'D') {
            tableau[Pos_x + 1][Pos_y] = 'P';
            tableau[Pos_x][Pos_y] = 'V';
            ++coinScore;
            globalScore += 250;
        }
        afficherMap();
    }//S'IL ENTRE LA TOUCHE D
    else if (e.keyCode == 68) {
        if (tableau[Pos_x][Pos_y + 1] == 'T' || tableau[Pos_x][Pos_y + 1] == 'V') {
            tableau[Pos_x][Pos_y + 1] = 'P';
            tableau[Pos_x][Pos_y] = 'V';
        } else if (tableau[Pos_x][Pos_y + 1] == 'M' || tableau[Pos_x][Pos_y + 1] == 'C') {
            tableau[Pos_x][Pos_y] = 'P';
        } else if (tableau[Pos_x][Pos_y + 1] == 'D') {
            tableau[Pos_x][Pos_y + 1] = 'P';
            tableau[Pos_x][Pos_y] = 'V';
            ++coinScore;
            globalScore += 250;
        } else if (tableau[Pos_x][Pos_y + 1] == 'R' && tableau[Pos_x][Pos_y + 2] == 'V') {
            tableau[Pos_x][Pos_y + 1] = 'P';
            tableau[Pos_x][Pos_y + 2] = 'R';
            tableau[Pos_x][Pos_y] = 'V';
        } else if (tableau[Pos_x][Pos_y + 1] == 'R' && (tableau[Pos_x][Pos_y + 2] == 'M' || tableau[Pos_x][Pos_y + 2] == 'C' || tableau[Pos_x][Pos_y + 2] == 'T' || tableau[Pos_x][Pos_y + 2] == 'D')) {
            tableau[Pos_x][Pos_y] = 'P';
        }

        afficherMap();
    }//S'IL ENTRE LA TOUCHE Q
    else if (e.keyCode == 81) {
        if (tableau[Pos_x][Pos_y - 1] == 'T' || tableau[Pos_x][Pos_y - 1] == 'V') {
            tableau[Pos_x][Pos_y - 1] = 'P';
            tableau[Pos_x][Pos_y] = 'V';
        } else if (tableau[Pos_x][Pos_y - 1] == 'M' || tableau[Pos_x][Pos_y - 1] == 'C') {
            tableau[Pos_x][Pos_y] = 'P';
        } else if (tableau[Pos_x][Pos_y - 1] == 'D') {
            tableau[Pos_x][Pos_y - 1] = 'P';
            tableau[Pos_x][Pos_y] = 'V';
            ++coinScore;
            globalScore += 250;
        } else if (tableau[Pos_x][Pos_y - 1] == 'R' && tableau[Pos_x][Pos_y - 2] == 'V') {
            tableau[Pos_x][Pos_y - 1] = 'P';
            tableau[Pos_x][Pos_y - 2] = 'R'
            tableau[Pos_x][Pos_y] = 'V';
        } else if (tableau[Pos_x][Pos_y - 1] == 'R' && (tableau[Pos_x][Pos_y - 2] == 'M' || tableau[Pos_x][Pos_y - 2] == 'C' || tableau[Pos_x][Pos_y - 2] == 'T' || tableau[Pos_x][Pos_y - 2] == 'D')) {
            tableau[Pos_x][Pos_y] = 'P';
        }
        afficherMap(); 
    }
    //++moveCount;
    globalScore -= 1;
    refreshSB();
    
}

//GRAVITE
function gravity() {

    tableau.forEach((row, i) => {
        row.forEach((symbol, j) => {
            if (symbol == 'R') {
                x = i;
                y = j;
                if (tableau[x + 1][y] == 'V') {
                    tableau[x + 1][y] = 'R';
                    tableau[x][y] = 'V';
                    afficherMap();
                    if (tableau[x + 1][y] == 'P') {
                    life -= life;
                        if (life > 0) {
                            reset();
                        } else if (life == 0) {
                            gameOver();
                        }

                    }
                }
            }
        })
    })

}



//TIMER 
function timer() {
    let tempsmax=200; 
    const timerElement = document.getElementById("timer")
    setInterval(() => {
        timerElement.textContent = `Timer : ${tempsmax}`
        tempsmax = tempsmax <= 0 ? 0 : tempsmax-1
    }, 1000)
}

//RESET
function reset() {
    coinScore = 0;
    globalScore = 0;
    life -= 1;
    refreshSB();
    afficherMap();
}

//GAME OVER
function gameOver() {
    endSreen.innerHTML = `<div class="gameOver">Game over <br/>Score : ${globalScore} </div>`;
    endSreen.style.visibility = 'visible';
    endSreen.style.opacity = '1';
};


//APPEL DES FONCTIONS
    
afficherMap();
timer();
compteCoinMap();
document.body.addEventListener('keydown', move);
