
 window.onload = function () {
            console.log(0)
            document.body.onkeydown = function start(e) {
                var key = e.which
                if (key) {
                    console.log('enter')
                    document.location.href = 'index.html'
                }

            }
            
            var czy_mrug = false
            setInterval(mrug, 500)
            function mrug(){
                if (czy_mrug) {
                    document.getElementById('enter').style.display = 'none'
                    czy_mrug = false
                }
                else{
                    document.getElementById('enter').style.display = 'block'
                    czy_mrug = true
                }
            }
           
        } 